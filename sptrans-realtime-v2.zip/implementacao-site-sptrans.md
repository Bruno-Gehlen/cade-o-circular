# Implementação do Site Monitor de Ônibus USP Butantã

Este documento contém as instruções completas para implementar e hospedar o site de monitoramento de ônibus da SPTrans para as linhas da USP Butantã na Vercel.

## Visão Geral do Projeto

O site desenvolvido é uma aplicação web que simula um monitor de ônibus em tempo real para as linhas que atendem à USP Butantã. Ele inclui:

- **Linhas monitoradas**: 8082-10, 8083-10, 8084-10, 8085-10, 8012-10, 8022-10
- **Mapa interativo** usando Leaflet.js
- **Dados simulados** que representam posicionamento realístico dos ônibus
- **Interface responsiva** com tema claro/escuro
- **Tempos estimados** de chegada nos pontos

## Estrutura de Arquivos

```
sptrans-monitor/
├── index.html          # Página principal
├── style.css           # Estilos da aplicação
├── app.js             # Lógica JavaScript
└── README.md          # Documentação
```

## Funcionalidades Implementadas

### 1. Mapa Interativo
- **Biblioteca**: Leaflet.js com tiles do OpenStreetMap
- **Localização**: Centrado na USP Butantã (-23.5558, -46.7316)
- **Marcadores**: Ônibus com cores por linha e pontos de referência
- **Popups**: Informações detalhadas de cada ônibus

### 2. Seletor de Linhas
- Checkboxes para cada linha de ônibus
- Cores distintivas para identificação
- Possibilidade de selecionar múltiplas linhas
- Atualização em tempo real

### 3. Simulação de Dados Realística
- Posicionamento dos ônibus baseado em rotas reais
- Velocidades entre 15-40 km/h
- Movimentação gradual dos veículos
- Horários de funcionamento corretos

### 4. Interface do Usuário
- Design responsivo para desktop e mobile
- Tema claro/escuro alternável
- Painel lateral com controles
- Informações de status em tempo real

## Como Hospedar na Vercel

### Passo 1: Preparar os Arquivos
1. Crie uma pasta local para o projeto
2. Baixe os arquivos gerados pelo aplicativo
3. Organize na estrutura mostrada acima

### Passo 2: Criar Repositório no GitHub
```bash
# Inicializar repositório Git
git init

# Adicionar arquivos
git add .

# Commit inicial
git commit -m "Implementação inicial do monitor de ônibus USP"

# Conectar ao GitHub (substitua pelo seu repositório)
git remote add origin https://github.com/seuusuario/sptrans-monitor.git

# Push para o GitHub
git push -u origin main
```

### Passo 3: Deploy na Vercel
1. **Via Interface Web**:
   - Acesse [vercel.com](https://vercel.com)
   - Faça login com sua conta GitHub
   - Clique em "New Project"
   - Selecione seu repositório
   - Configure como "Other" (site estático)
   - Clique em "Deploy"

2. **Via CLI da Vercel**:
```bash
# Instalar CLI da Vercel
npm i -g vercel

# Deploy
vercel

# Seguir instruções na tela
```

### Passo 4: Configurações da Vercel
O site funcionará automaticamente como site estático. Configurações opcionais no arquivo `vercel.json`:

```json
{
  "builds": [
    { "src": "*.html", "use": "@vercel/static" }
  ],
  "routes": [
    { "src": "/(.*)", "dest": "/index.html" }
  ]
}
```

## Funcionalidades Técnicas

### API SPTrans (Implementação Futura)
Para conectar com a API real da SPTrans, será necessário:

1. **Obter Token de Acesso**:
   - Cadastrar-se no portal de desenvolvedores da SPTrans
   - Criar aplicação e obter token
   - Documentação: [SPTrans API](http://www.sptrans.com.br/desenvolvedores/)

2. **Implementar Autenticação**:
```javascript
// Exemplo de autenticação
const API_BASE = 'http://api.olhovivo.sptrans.com.br/v2.1';
const TOKEN = 'seu_token_aqui';

async function authenticate() {
    const response = await fetch(`${API_BASE}/Login/Autenticar?token=${TOKEN}`, {
        method: 'POST'
    });
    return response.ok;
}
```

3. **Resolver CORS**:
   - Usar proxy CORS ou implementar backend
   - Alternativas: cors-anywhere, próprio servidor proxy

4. **Endpoints Principais**:
```javascript
// Buscar linhas
`${API_BASE}/Linha/Buscar?termosBusca=${linha}`

// Posição dos ônibus
`${API_BASE}/Posicao/Linha?codigoLinha=${codigo}`

// Previsão de chegada
`${API_BASE}/Previsao/Linha?codigoLinha=${codigo}&codigoParada=${parada}`
```

## Melhorias e Extensões

### 1. Funcionalidades Avançadas
- **Notificações push** para chegada de ônibus
- **Histórico de viagens** e padrões de atraso
- **Integração com outras APIs** de transporte (Metrô, CPTM)
- **Rotas otimizadas** entre pontos

### 2. Performance e UX
- **Service Worker** para funcionamento offline
- **Progressive Web App (PWA)** para instalação mobile
- **Geolocalização** para encontrar paradas próximas
- **Favoritos** para linhas mais usadas

### 3. Dados e Analytics
- **Analytics** de uso das linhas
- **Relatórios** de pontualidade
- **Previsões melhoradas** com machine learning
- **Integração** com dados de trânsito

## Limitações Atuais

1. **Dados Simulados**: Não conecta à API real da SPTrans
2. **CORS**: API da SPTrans não suporta requisições diretas do browser
3. **Tempo Real**: Simulação baseada em algoritmos, não dados reais
4. **Cobertura**: Apenas linhas da USP Butantã

## Roadmap de Desenvolvimento

### Fase 1 (Atual)
- ✅ Interface básica funcional
- ✅ Simulação de dados
- ✅ Mapa interativo
- ✅ Deploy na Vercel

### Fase 2 (Próximos passos)
- [ ] Backend proxy para API SPTrans
- [ ] Dados reais de posicionamento
- [ ] Notificações push
- [ ] PWA implementation

### Fase 3 (Futuro)
- [ ] Integração com outras APIs
- [ ] Analytics avançados
- [ ] Machine learning para previsões
- [ ] Aplicativo mobile nativo

## Suporte e Documentação

- **Leaflet.js**: [leafletjs.com](https://leafletjs.com/)
- **Vercel Docs**: [vercel.com/docs](https://vercel.com/docs)
- **SPTrans API**: [Portal Desenvolvedores](http://www.sptrans.com.br/desenvolvedores/)
- **CORS Solutions**: [Proxy services](https://github.com/Rob--W/cors-anywhere)

## Contato e Contribuições

Este projeto é open-source e aceita contribuições. Para implementar melhorias ou reportar bugs, criar issues no repositório GitHub.

---

**Nota**: Este site funciona como demonstração das funcionalidades propostas. Para implementação com dados reais, é necessário desenvolver um backend que faça a ponte com a API da SPTrans, contornando as limitações de CORS.